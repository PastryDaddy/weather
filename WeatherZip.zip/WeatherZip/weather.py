from flask import Flask, request, jsonify
import requests
import json

app = Flask(__name__)
def cityWeather():
    api_key = "26179338be114ad4875164551243007"
    base_url = f"https://api.weatherapi.com/v1/current.json?key={api_key}&q="
    city = input("Which city's weather would you like to see?\n")
    try:
        response = requests.get(base_url + city)
        response.raise_for_status() 

        data = response.json()
        if data.get("error"):
            return {"error": data["error"]["message"]}, 404

        weather_data = {
            "City": data["location"]["name"],
            "Temp": data["current"]["temp_f"],
            "Conditions": data["current"]["condition"]["text"],
            "Humidity": data["current"]["humidity"],
            "Wind Speed": data["current"]["wind_mph"]
        }

        return f"""Your Weather Report:
                City: {weather_data['City']}
                Temp: {weather_data["Temp"]}F
                Conditions: {weather_data["Conditions"]}
                Humidity: {weather_data["Humidity"]}
                Wind Speed: {weather_data["Wind Speed"]}mph"""
        

    except requests.exceptions.RequestException as e:
        print(f"Sorry, there's a problem: {e}"), 500


# @app.route("/weather", methods=["GET"])
# def get_weather():
#     city = request.args.get("city")
#     if city:
#         return jsonify(cityWeather(city))
#     else:
#         return jsonify({"error": "Please enter the name of a city"}), 400
                                    
# if __name__ == "__main__":
#    app.run()
print(cityWeather())